import React from 'react';
import { Route } from 'react-router';
import ListPage from './pages/ListPage';

const App = () => {
  return (
    <div>
      <ListPage />
    </div>
  );
};

export default App;
